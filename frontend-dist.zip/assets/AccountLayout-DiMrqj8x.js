import{r as e}from"./rolldown-runtime-S-ySWqyJ.js";import{c as t}from"./forms-BGzRbOu4.js";import{M as n,u as r}from"./react-Cu3Ahjty.js";import{n as i,x as a}from"./index-DKWzb5HB.js";var o=e(t(),1),s=r(),c=`
  .acct-input {
    display: block; width: 100%;
    background: #EDE8DC; border: 1px solid #E2DAC8; border-radius: 4px;
    padding: 12px 16px;
    font-family: Jost, system-ui, sans-serif; font-size: 14px; color: #1C1A17;
    outline: none; box-sizing: border-box;
    transition: border-color 150ms, box-shadow 150ms;
  }
  .acct-input:focus { border-color: #7B5EA7; box-shadow: 0 0 0 3px #F0EAF7; }
  .acct-input::placeholder { color: #C4B89A; }
  .acct-input:disabled { opacity: 0.6; cursor: not-allowed; }

  .acct-btn-gold {
    display: inline-flex; align-items: center; justify-content: center;
    background: #C49A3C; color: #fff; border: none; border-radius: 4px;
    font-family: Jost, system-ui, sans-serif; font-size: 11px; font-weight: 400;
    text-transform: uppercase; letter-spacing: 0.1em;
    padding: 12px 28px; cursor: pointer;
    transition: background 150ms, transform 100ms;
  }
  .acct-btn-gold:hover:not(:disabled) { background: #D4B060; transform: translateY(-1px); }
  .acct-btn-gold:disabled { opacity: 0.6; cursor: not-allowed; }

  .acct-btn-ghost {
    display: inline-flex; align-items: center; justify-content: center;
    background: none; color: #6B6057;
    border: 1px solid #E2DAC8; border-radius: 4px;
    font-family: Jost, system-ui, sans-serif; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.1em;
    padding: 12px 24px; cursor: pointer;
    transition: border-color 150ms, color 150ms;
  }
  .acct-btn-ghost:hover:not(:disabled) { border-color: #C4B89A; color: #1C1A17; }
  .acct-btn-ghost:disabled { opacity: 0.6; cursor: not-allowed; }

  .acct-btn-danger {
    display: inline-flex; align-items: center; justify-content: center;
    background: none; color: #A85050;
    border: 1px solid #E2C8C8; border-radius: 4px;
    font-family: Jost, system-ui, sans-serif; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.1em;
    padding: 12px 24px; cursor: pointer;
    transition: background 150ms, border-color 150ms;
  }
  .acct-btn-danger:hover { background: #FDF0F0; border-color: #A85050; }

  .acct-label {
    display: block;
    font-family: Jost, system-ui, sans-serif; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.08em; color: #6B6057;
    margin-bottom: 6px;
  }
  .acct-error {
    font-family: Jost, system-ui, sans-serif; font-size: 12px; color: #A85050;
    margin-top: 4px;
  }
  .acct-section-header {
    margin-bottom: 32px;
  }
  .acct-eyebrow {
    font-family: Jost, system-ui, sans-serif; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.18em; color: #C49A3C;
  }
  .acct-page-title {
    font-family: "Cormorant Garamond", Georgia, serif; font-weight: 300;
    font-size: clamp(24px, 4vw, 32px); color: #1C1A17; margin: 6px 0 0;
  }
`,l=[{key:`orders`,label:`My Orders`,mobileLabel:`Orders`,path:`/account/orders`},{key:`rewards`,label:`My Rewards`,mobileLabel:`Rewards`,path:`/account/rewards`},{key:`addresses`,label:`My Addresses`,mobileLabel:`Addresses`,path:`/account/addresses`},{key:`profile`,label:`Profile`,mobileLabel:`Profile`,path:`/account/profile`}],u=({children:e,activeTab:t})=>{let r=n(),u=i(e=>e.user),d=i(e=>e.logout);if((0,o.useEffect)(()=>{u||r(`/auth/login`,{replace:!0})},[u,r]),!u)return null;let f=u.name.trim().split(/\s+/).map(e=>e[0]).slice(0,2).join(``).toUpperCase(),p=e=>{r(e),window.scrollTo({top:0})},m=async()=>{await d(),r(`/`),window.scrollTo({top:0})};return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:c}),(0,s.jsx)(a,{}),(0,s.jsxs)(`div`,{style:{minHeight:`100vh`,background:`#F5F0E8`,paddingTop:72,display:`flex`},children:[(0,s.jsxs)(`aside`,{className:`hidden md:flex`,style:{width:240,flexShrink:0,flexDirection:`column`,background:`#EDE8DC`,borderRight:`1px solid #E2DAC8`,position:`sticky`,top:72,height:`calc(100vh - 72px)`,overflowY:`auto`},children:[(0,s.jsxs)(`div`,{style:{padding:`32px 24px 20px`},children:[(0,s.jsx)(`div`,{style:{width:52,height:52,borderRadius:`50%`,background:u.avatar?`transparent`:`#7B5EA7`,display:`flex`,alignItems:`center`,justifyContent:`center`,marginBottom:12,overflow:`hidden`},children:u.avatar?(0,s.jsx)(`img`,{src:u.avatar,alt:u.name,style:{width:`100%`,height:`100%`,objectFit:`cover`}}):(0,s.jsx)(`span`,{style:{color:`#fff`,fontFamily:`Jost`,fontSize:18,fontWeight:500,lineHeight:1},children:f})}),(0,s.jsx)(`p`,{style:{fontFamily:`Jost`,fontWeight:500,fontSize:14,color:`#1C1A17`,margin:0},children:u.name}),(0,s.jsx)(`p`,{style:{fontFamily:`Jost`,fontSize:12,color:`#6B6057`,margin:`4px 0 0`},children:u.phone??u.email})]}),(0,s.jsx)(`div`,{style:{height:1,background:`#E2DAC8`}}),(0,s.jsx)(`nav`,{style:{paddingTop:12,flex:1},children:l.map(e=>{let n=t===e.key;return(0,s.jsx)(`button`,{onClick:()=>p(e.path),style:{display:`block`,width:`100%`,textAlign:`left`,padding:`11px 24px`,fontFamily:`Jost`,fontSize:11,textTransform:`uppercase`,letterSpacing:`0.1em`,background:n?`#F0EAF7`:`none`,color:n?`#7B5EA7`:`#6B6057`,border:`none`,borderLeft:`2px solid ${n?`#7B5EA7`:`transparent`}`,cursor:`pointer`,transition:`background 150ms, color 150ms`},children:e.label},e.key)})}),(0,s.jsxs)(`div`,{style:{padding:`8px 0 28px`},children:[(0,s.jsx)(`div`,{style:{height:1,background:`#E2DAC8`,marginBottom:8}}),(0,s.jsx)(`button`,{onClick:()=>{m()},style:{display:`block`,width:`100%`,textAlign:`left`,padding:`11px 24px`,fontFamily:`Jost`,fontSize:11,textTransform:`uppercase`,letterSpacing:`0.1em`,background:`none`,color:`#A85050`,border:`none`,borderLeft:`2px solid transparent`,cursor:`pointer`},children:`Logout`})]})]}),(0,s.jsx)(`main`,{style:{flex:1,minWidth:0,padding:`48px clamp(24px, 5vw, 80px)`},className:`pb-24 md:pb-12`,children:e})]}),(0,s.jsx)(`div`,{className:`flex md:hidden`,style:{position:`fixed`,top:72,left:0,right:0,zIndex:150,background:`#EDE8DC`,borderBottom:`1px solid #E2DAC8`},children:l.map(e=>{let n=t===e.key;return(0,s.jsx)(`button`,{onClick:()=>p(e.path),style:{flex:1,padding:`10px 2px`,fontFamily:`Jost`,fontSize:8,textTransform:`uppercase`,letterSpacing:`0.06em`,background:n?`#F0EAF7`:`none`,color:n?`#7B5EA7`:`#6B6057`,border:`none`,borderBottom:`2px solid ${n?`#7B5EA7`:`transparent`}`,cursor:`pointer`,textAlign:`center`},children:e.mobileLabel},e.key)})})]})};export{u as t};