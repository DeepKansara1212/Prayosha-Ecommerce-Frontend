import{r as e}from"./rolldown-runtime-S-ySWqyJ.js";import{c as t}from"./forms-BGzRbOu4.js";import{u as n}from"./react-Cu3Ahjty.js";var r=e(t(),1),i=n(),a=`
  .auth-shell {
    display: grid;
    grid-template-columns: 5fr 7fr;
    min-height: 100vh;
  }
  .auth-input {
    display: block;
    width: 100%;
    background: #EDE8DC;
    border-radius: 4px;
    padding: 12px 16px;
    font-family: Jost, system-ui, sans-serif;
    font-size: 14px;
    color: #1C1A17;
    outline: none;
    transition: border-color 150ms, box-shadow 150ms;
    box-sizing: border-box;
  }
  .auth-input:focus {
    border-color: #7B5EA7 !important;
    box-shadow: 0 0 0 3px #F0EAF7;
  }
  .auth-btn-primary {
    display: block;
    width: 100%;
    background: #C49A3C;
    color: #fff;
    font-family: Jost, system-ui, sans-serif;
    font-size: 11px;
    font-weight: 400;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    padding: 14px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    transition: background 150ms, transform 150ms;
  }
  .auth-btn-primary:hover:not(:disabled) {
    background: #D4B060;
    transform: translateY(-1px);
  }
  .auth-btn-primary:disabled {
    opacity: 0.65;
    cursor: not-allowed;
    transform: none;
  }
  .auth-btn-secondary {
    display: block;
    width: 100%;
    background: transparent;
    border: 1px solid #C49A3C;
    color: #C49A3C;
    font-family: Jost, system-ui, sans-serif;
    font-size: 11px;
    font-weight: 400;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    padding: 14px;
    border-radius: 4px;
    cursor: pointer;
    transition: background 150ms;
  }
  .auth-btn-secondary:hover:not(:disabled) {
    background: #FBF6EC;
  }
  .auth-btn-secondary:disabled {
    opacity: 0.65;
    cursor: not-allowed;
  }
  @media (max-width: 899px) {
    .auth-shell {
      grid-template-columns: 1fr;
    }
    .auth-shell-left {
      height: 100px !important;
      padding: 0 1.5rem !important;
      overflow: hidden;
      justify-content: flex-start !important;
    }
    .auth-shell-left .auth-left-body {
      flex-direction: row !important;
      align-items: center;
      gap: 0.85rem;
      max-width: none !important;
    }
    .auth-shell-left .auth-headline,
    .auth-shell-left .auth-headline-italic,
    .auth-shell-left .auth-subtext { display: none; }
    .auth-shell-right-inner {
      padding: 2rem 1.5rem !important;
    }
  }
`,o=({headline:e,headlineItalic:t,subtext:n,children:r})=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`style`,{children:a}),(0,i.jsxs)(`div`,{className:`auth-shell`,children:[(0,i.jsxs)(`div`,{className:`auth-shell-left`,style:{background:`radial-gradient(ellipse at 30% 50%, #E8DFF5 0%, #F5F0E8 50%, #EDE4D0 100%)`,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:`3rem 2.5rem`,position:`relative`,overflow:`hidden`},children:[(0,i.jsx)(`div`,{"aria-hidden":!0,style:{position:`absolute`,top:`2rem`,right:`2rem`,width:`70px`,height:`70px`,borderRadius:`50%`,background:`radial-gradient(circle at 35% 35%, #9B7EC8, #C49A3C)`,boxShadow:`0 0 28px rgba(123,94,167,0.45), 0 0 60px rgba(196,154,60,0.2)`,flexShrink:0}}),(0,i.jsxs)(`div`,{className:`auth-left-body`,style:{maxWidth:`420px`,width:`100%`,display:`flex`,flexDirection:`column`},children:[(0,i.jsx)(`p`,{style:{fontFamily:`Jost, system-ui, sans-serif`,fontSize:`10px`,letterSpacing:`0.15em`,textTransform:`uppercase`,color:`#6B6057`,margin:`0 0 1.75rem`},children:`✦ PRAYOSHA CRYSTAL`}),(0,i.jsx)(`h1`,{className:`auth-headline`,style:{fontFamily:`"Cormorant Garamond", Georgia, serif`,fontWeight:300,fontSize:`clamp(32px, 4vw, 52px)`,color:`#1C1A17`,lineHeight:1.12,margin:`0 0 0.2rem`},children:e}),(0,i.jsx)(`p`,{className:`auth-headline-italic`,style:{fontFamily:`"Cormorant Garamond", Georgia, serif`,fontWeight:300,fontStyle:`italic`,fontSize:`clamp(28px, 3.5vw, 46px)`,color:`#7B5EA7`,lineHeight:1.12,margin:`0 0 1.5rem`},children:t}),(0,i.jsx)(`p`,{className:`auth-subtext`,style:{fontFamily:`Jost, system-ui, sans-serif`,fontWeight:300,fontSize:`15px`,color:`#6B6057`,maxWidth:`340px`,lineHeight:1.65,margin:0},children:n})]})]}),(0,i.jsx)(`div`,{className:`auth-shell-right`,style:{background:`#F5F0E8`,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,i.jsx)(`div`,{className:`auth-shell-right-inner`,style:{maxWidth:`400px`,width:`100%`,padding:`48px 40px`},children:r})})]})]}),s={display:`block`,fontFamily:`Jost, system-ui, sans-serif`,fontSize:`11px`,textTransform:`uppercase`,letterSpacing:`0.1em`,color:`#6B6057`,marginBottom:`6px`},c={fontFamily:`Jost, system-ui, sans-serif`,fontSize:`11px`,color:`#A85050`,marginTop:`4px`};function l(e){return{border:`1px solid ${e?`#A85050`:`#E2DAC8`}`}}var u=(0,r.forwardRef)(({label:e,error:t,...n},r)=>(0,i.jsxs)(`div`,{children:[(0,i.jsx)(`label`,{style:s,children:e}),(0,i.jsx)(`input`,{ref:r,className:`auth-input`,style:l(!!t),...n}),t&&(0,i.jsx)(`p`,{role:`alert`,style:c,children:t})]}));u.displayName=`FormField`;var d=(0,r.forwardRef)(({label:e,error:t,style:n,...a},o)=>{let[u,d]=(0,r.useState)(!1);return(0,i.jsxs)(`div`,{children:[(0,i.jsx)(`label`,{style:s,children:e}),(0,i.jsxs)(`div`,{style:{position:`relative`},children:[(0,i.jsx)(`input`,{ref:o,className:`auth-input`,type:u?`text`:`password`,style:{...l(!!t),paddingRight:`44px`},...a}),(0,i.jsx)(`button`,{type:`button`,onClick:()=>d(e=>!e),"aria-label":u?`Hide password`:`Show password`,style:{position:`absolute`,right:`12px`,top:`50%`,transform:`translateY(-50%)`,background:`none`,border:`none`,cursor:`pointer`,color:`#6B6057`,padding:0,lineHeight:0},children:u?(0,i.jsxs)(`svg`,{viewBox:`0 0 24 24`,width:`16`,height:`16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,children:[(0,i.jsx)(`path`,{d:`M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24`}),(0,i.jsx)(`line`,{x1:`1`,y1:`1`,x2:`23`,y2:`23`})]}):(0,i.jsxs)(`svg`,{viewBox:`0 0 24 24`,width:`16`,height:`16`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,children:[(0,i.jsx)(`path`,{d:`M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z`}),(0,i.jsx)(`circle`,{cx:`12`,cy:`12`,r:`3`})]})})]}),t&&(0,i.jsx)(`p`,{role:`alert`,style:c,children:t})]})});d.displayName=`PasswordField`;var f=({message:e})=>(0,i.jsxs)(`div`,{role:`alert`,style:{background:`#FDF0F0`,border:`1px solid rgba(168,80,80,0.3)`,borderRadius:`4px`,padding:`12px 14px`,display:`flex`,gap:`8px`,alignItems:`flex-start`},children:[(0,i.jsx)(`span`,{style:{color:`#A85050`,fontSize:`14px`,lineHeight:1,flexShrink:0},children:`✕`}),(0,i.jsx)(`p`,{style:{fontFamily:`Jost, system-ui, sans-serif`,fontSize:`13px`,color:`#A85050`,margin:0},children:e})]}),p=({children:e,onClick:t})=>(0,i.jsx)(`button`,{type:`button`,onClick:t,style:{fontFamily:`Jost, system-ui, sans-serif`,fontSize:`13px`,color:`#7B5EA7`,background:`none`,border:`none`,cursor:`pointer`,padding:0,textDecoration:`underline`,textDecorationColor:`rgba(123,94,167,0.4)`,textUnderlineOffset:`2px`},children:e}),m=({message:e})=>(0,i.jsx)(`div`,{style:{background:`#F0F7F0`,border:`1px solid rgba(80,140,80,0.3)`,borderRadius:`4px`,padding:`12px 14px`,fontFamily:`Jost, system-ui, sans-serif`,fontSize:`13px`,color:`#3D6B40`},children:e});export{m as a,u as i,o as n,d as o,f as r,p as t};